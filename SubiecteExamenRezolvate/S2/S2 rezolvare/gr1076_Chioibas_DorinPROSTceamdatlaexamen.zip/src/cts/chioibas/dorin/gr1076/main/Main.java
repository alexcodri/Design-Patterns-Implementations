package cts.chioibas.dorin.gr1076.main;

import cts.chioibas.dorin.gr1076.patternState.Bariera;
import cts.chioibas.dorin.gr1076.patternState.BarieraCoborata;
import cts.chioibas.dorin.gr1076.patternState.BarieraCount;
import cts.chioibas.dorin.gr1076.patternState.BarieraRidicata;

public class Main {
    public static void main(String[] args) {

        Bariera bariera1 = new Bariera(5);
        bariera1.setDurata(20);
        bariera1.setFlagCoborare(true);
        bariera1.setiTrecereCaleFerata(new BarieraCount());
        bariera1.setDurata(5);
        bariera1.seApropieTren();
        bariera1.setiTrecereCaleFerata(new BarieraRidicata());
        bariera1.barieraRidicata();
        bariera1.setiTrecereCaleFerata(new BarieraCoborata());
        bariera1.barieraCoborata();




    }
}
