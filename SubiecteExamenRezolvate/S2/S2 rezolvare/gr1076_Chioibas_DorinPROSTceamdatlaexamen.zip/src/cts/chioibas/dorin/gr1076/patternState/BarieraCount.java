package cts.chioibas.dorin.gr1076.patternState;

public class BarieraCount implements ITrecereCaleFerata {

    public void schimbaStare(Bariera bariera) {
        bariera.setiTrecereCaleFerata(this);
    }

    @Override
    public void pornesteAvertizareSonora(long durata) {
        if (durata < 10) {
            System.out.println("AVERTIZARE SONORA");
        }
    }

    @Override
    public void ridicaBariera() {

    }

    @Override
    public void coboaraBariera() {

    }

    @Override
    public boolean seApropieTren() {
        return true;
    }

    @Override
    public boolean trenulATrecut() {
        return false;
    }
}
