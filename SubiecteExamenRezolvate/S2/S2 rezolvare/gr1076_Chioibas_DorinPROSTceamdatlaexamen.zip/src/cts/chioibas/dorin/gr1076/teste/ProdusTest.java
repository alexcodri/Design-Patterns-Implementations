package cts.chioibas.dorin.gr1076.teste;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class ProdusTest {

    @Test
    public void setPretLowerBoundary() {
        Produs produs = new Produs("Prod1", 22.5);
        produs.setPret(22.5, 1);
        assertEquals(produs.getPret(), 22.5, 0.01);
    }

    @Test
    public void setPretUpperBoundary() {
        Produs produs = new Produs("Prod1", 22.5);
        produs.setPret(20.0, 2);
        assertEquals(produs.getPret(), 10.0, 0.01);
    }

    @Test
    public void setRange() {
        Produs produs = new Produs("Prod1", 22.5);
        produs.setPret(22.5, 50);
        assertEquals(produs.getPret(), 22.5, 0.01);
    }
}