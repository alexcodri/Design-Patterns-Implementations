package cts.chioibas.dorin.gr1076.patternState;

public class BarieraCoborata implements ITrecereCaleFerata {

    public void schimbaStare(Bariera bariera) {
        bariera.setiTrecereCaleFerata(this);
    }

    @Override
    public void pornesteAvertizareSonora(long durata) {

    }

    @Override
    public void ridicaBariera() {

    }

    @Override
    public void coboaraBariera() {
        System.out.println("BARIERA SE COBOARA");
    }

    @Override
    public boolean seApropieTren() {
        return false;
    }

    @Override
    public boolean trenulATrecut() {
        return false;
    }
}
