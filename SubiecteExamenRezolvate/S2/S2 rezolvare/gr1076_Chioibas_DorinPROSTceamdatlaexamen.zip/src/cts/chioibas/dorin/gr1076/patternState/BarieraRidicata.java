package cts.chioibas.dorin.gr1076.patternState;

public class BarieraRidicata implements ITrecereCaleFerata {

    public void schimbaStare(Bariera bariera) {
        bariera.setiTrecereCaleFerata(this);
    }
    @Override
    public void pornesteAvertizareSonora(long durata) {

    }

    @Override
    public void ridicaBariera() {
        System.out.println("BARIERA SE RIDICA");
    }

    @Override
    public void coboaraBariera() {

    }

    @Override
    public boolean seApropieTren() {
        return false;
    }

    @Override
    public boolean trenulATrecut() {
        return false;
    }
}
