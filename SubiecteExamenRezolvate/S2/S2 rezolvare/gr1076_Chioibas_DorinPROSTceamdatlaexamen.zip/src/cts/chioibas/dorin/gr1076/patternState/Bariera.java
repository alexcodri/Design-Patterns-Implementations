package cts.chioibas.dorin.gr1076.patternState;

import com.sun.java.swing.plaf.windows.WindowsTreeUI;

public class Bariera {
    private int idBariera;
    private boolean flagCoborare;
    private ITrecereCaleFerata iTrecereCaleFerata;
    private long durata;

    public Bariera(int idBariera) {
        this.idBariera = idBariera;
    }

    public int getIdBariera() {
        return idBariera;
    }

    public void setIdBariera(int idBariera) {
        this.idBariera = idBariera;
    }

    public boolean isFlagCoborare() {
        return flagCoborare;
    }

    public void setFlagCoborare(boolean flagCoborare) {
        this.flagCoborare = flagCoborare;
    }

    public ITrecereCaleFerata getiTrecereCaleFerata() {
        return iTrecereCaleFerata;
    }

    public void setiTrecereCaleFerata(ITrecereCaleFerata iTrecereCaleFerata) {
        this.iTrecereCaleFerata = iTrecereCaleFerata;
    }

    public long getDurata() {
        return durata;
    }

    public void setDurata(long durata) {
        this.durata = durata;
    }


    public void seApropieTren() {
        if (iTrecereCaleFerata instanceof BarieraCount && durata <= 10) {
            iTrecereCaleFerata.pornesteAvertizareSonora(durata);
        }
    }

    public void barieraCoborata() {
        if (iTrecereCaleFerata instanceof BarieraCoborata) {
            iTrecereCaleFerata.coboaraBariera();
        }
    }

    public void barieraRidicata() {
        if (iTrecereCaleFerata instanceof BarieraRidicata) {
            iTrecereCaleFerata.ridicaBariera();
        }
    }
}
